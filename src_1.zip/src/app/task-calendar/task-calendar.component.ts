import { Component, OnInit } from '@angular/core';
import { Task } from '../models/task';
import { TaskCalendarService } from '../services/taskCalendarService';
import { AuthService } from '../services/auth-service/auth.service';

@Component({
  selector: 'app-task-calendar',
  templateUrl: './task-calendar.component.html',
  styleUrls: ['./task-calendar.component.css']
})
export class TaskCalendarComponent implements OnInit {
  tasks: Task[] = [];
  userId: number;
  dates: number[] = [];
  days: string[] = [];
  taskMap: { [date: number]: Task[] } = {};

  constructor(private taskCalendarService: TaskCalendarService, public authService: AuthService) {
    this.userId = 0;
  }

  ngOnInit() {
    // Retrieve user ID from auth service
    this.userId = this.authService.userProfile.userLoginDTO.userId;
    console.log(`User ID: ${this.userId}`);

    // Fetch tasks from the service
    this.taskCalendarService.getUserTasks(this.userId).subscribe(tasks => {
      this.tasks = tasks;
      this.populateCalendar();
    });
  }

  private populateCalendar() {
    const currentDate = new Date();
    const startDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const endDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
  
    this.dates = [];
    this.days = [];
    this.taskMap = {};
  
    for (let date = startDate; date <= endDate; date.setDate(date.getDate() + 1)) {
      const day = date.getDate();
      const taskDate = new Date(date);
      
      // Check if there are any tasks for this date
      const hasTasks = this.tasks.some(task => {
        const taskDueDate = new Date(task.dueDate);
        return taskDueDate.getDate() === day &&
               taskDueDate.getMonth() === currentDate.getMonth() &&
               taskDueDate.getFullYear() === currentDate.getFullYear();
      });
  
      if (hasTasks) {
        this.dates.push(day);
        this.days.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
        this.taskMap[day] = this.tasks.filter(task => {
          const taskDueDate = new Date(task.dueDate);
          return taskDueDate.getDate() === day;
        });
      }
    }
  }
}
  
  
