export class Task {
    taskId: number;
    title: string;
    description: string;
    dueDate: string;
    priority: string;  
    status: string;
    userId: number;

    constructor(
        taskId: number,
        title: string,
        description: string,
        dueDate: string,
        priority: string,
        status: string,
        userId: number
      ) {
        this.taskId = taskId;
        this.title = title;
        this.description = description;
        this.dueDate = dueDate;
        this.priority = priority;
        this.status = status;
        this.userId = userId;
      }
  }