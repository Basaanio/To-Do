import { Component, OnInit } from '@angular/core';
import { Task } from '../models/task';
import { DashboardService } from '../services/dashboardService';
import { AuthService } from '../services/auth-service/auth.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  tasks: Task[] = [];
  userId:number;

  constructor(private  dashboardService: DashboardService,public authService:AuthService) {
    this.userId = 0

  }
  

  ngOnInit() {
    // Retrieve tasks from the dashboard service
    this.userId = this.authService.userProfile.userLoginDTO.userId;
    console.log(this.userId);

    // Retrieve tasks using the user ID
    this.dashboardService.getUserTasks(this.userId).subscribe(tasks => {
      this.tasks = tasks;
    });
  }
}