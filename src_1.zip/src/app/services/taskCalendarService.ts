import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Task } from '../models/task';
import { AuthService } from './auth-service/auth.service';

@Injectable({
  providedIn: 'root'
})
export class TaskCalendarService {
  private apiUrl = 'http://localhost:8080/tasks'; // Adjust as needed

  constructor(private http: HttpClient, private authService: AuthService) {}

  getUserTasks(userId: number): Observable<Task[]> {
    const token = this.authService.userProfile?.jwt; // Ensure correct access
    if (!token) {
      console.error('Authorization token is missing.');
      return throwError(() => new Error('Authorization token is missing.'));
    }

    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    console.log(`Fetching tasks from URL: ${this.apiUrl}/user/${userId}`);
    console.log(`Authorization Token: ${token}`);

   // return this.http.get<Task[]>(`${this.apiUrl}/user/${userId}`, { headers }).pipe(
    return this.http.get<Task[]>(`${this.apiUrl}/user/${userId}`, { headers }).pipe(
      map(tasks => tasks),
      catchError(error => {
        console.error('Error fetching tasks:', error);
        return throwError(() => new Error('Failed to fetch tasks'));
      })
    );
  }
}
