import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { catchError, map, Observable, throwError } from "rxjs";
import { Task } from "../models/task";
import { AuthService } from "./auth-service/auth.service";

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  tasks: Task[] = [];
  constructor(public http: HttpClient,public authService:AuthService) {}

  getUserTasks(userId: number): Observable<Task[]> {
    const token = this.authService.userProfile.jwt
 
    const headers = new HttpHeaders().set('Authorization', `Bearer ${token}`);
    console.log(token);
    return this.http.get<Task[]>(`http://localhost:8080/tasks/user/${userId}`,{headers})
      .pipe(
        map(tasks => {
          this.tasks = tasks;
          // Store tasks locally if needed
          return tasks;
        }),
        catchError(error => {
          console.error('Error fetching tasks :', error);
          return throwError(() => new Error('Failed to fetch tasks'));
        })
      );
  }
}