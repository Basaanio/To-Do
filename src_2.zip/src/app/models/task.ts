// export class Task {
//     taskId: number;
//     title: string;
//     description: string;
//     dueDate: string;
//     priority: string;  
//     status: string;
//     userId: number;
//     collaborators?: Collaborator[];

//     constructor(
//         taskId: number,
//         title: string,
//         description: string,
//         dueDate: string,
//         priority: string,
//         status: string,
//         userId: number
//       ) {
//         this.taskId = taskId;
//         this.title = title;
//         this.description = description;
//         this.dueDate = dueDate;
//         this.priority = priority;
//         this.status = status;
//         this.userId = userId;
//         this.collaborators = [];
//       }
//   }

export interface Collaborator {
  userId: number;
  // Add other collaborator properties if needed
}

export class Task {
  taskId: number;
  title: string;
  description: string;
  dueDate: string;
  priority: string;
  status: string;
  userId: number;
  collaborators?: Collaborator[];

  constructor(
    taskId: number = 0,
    title: string = '',
    description: string = '',
    dueDate: string = '',
    priority: string = 'Medium',
    status: string = 'Pending',
    userId: number = 0,
    collaborators?: Collaborator[]
  ) {
    this.taskId = taskId;
    this.title = title;
    this.description = description;
    this.dueDate = dueDate;
    this.priority = priority;
    this.status = status;
    this.userId = userId;
    this.collaborators = collaborators || [];
  }
}

