// import { Component, OnInit } from '@angular/core';
// import { Task } from '../models/task';
// import { DashboardService } from '../services/dashboardService';
// import { AuthService } from '../services/auth-service/auth.service';

// @Component({
//   selector: 'app-dashboard',
//   templateUrl: './dashboard.component.html',
//   styleUrls: ['./dashboard.component.css']
// })
// export class DashboardComponent implements OnInit {
//   tasks: Task[] = [];
//   paginatedTasksArray: Task[][] = [];
//   currentPage: number = 1;
//   tasksPerPage: number = 4;
//   totalPages: number = 0;
//   userId: number = 0;

//   constructor(private dashboardService: DashboardService, public authService: AuthService) {}

//   ngOnInit() {
//     // Retrieve tasks from the dashboard service
//     this.userId = this.authService.userProfile.userLoginDTO.userId;

//     this.dashboardService.getUserTasks(this.userId).subscribe(tasks => {
//       // Sort tasks by date in ascending order
//       this.tasks = tasks.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

//       // Paginate tasks
//       this.paginateTasks();
//     });
//   }

//   paginateTasks() {
//     this.paginatedTasksArray = [];
//     for (let i = 0; i < this.tasks.length; i += this.tasksPerPage) {
//       this.paginatedTasksArray.push(this.tasks.slice(i, i + this.tasksPerPage));
//     }
//     this.totalPages = this.paginatedTasksArray.length;
//   }

//   paginatedTasks(): Task[] {
//     return this.paginatedTasksArray[this.currentPage - 1] || [];
//   }

//   nextPage() {
//     if (this.currentPage < this.totalPages) {
//       this.currentPage++;
//     }
//   }

//   previousPage() {
//     if (this.currentPage > 1) {
//       this.currentPage--;
//     }
//   }
// }

import { Component, OnInit } from '@angular/core';
import { Task } from '../../models/task';
import { DashboardService } from '../../services/dashboardService';
import { AuthService } from '../../services/auth-service/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  tasks: Task[] = [];
  filteredTasks: { [date: string]: Task[] } = {}; // Explicitly typing the object
  dates: string[] = [];
  paginatedDates: string[] = [];
  currentPage: number = 1;
  tasksPerPage: number = 4; // Adjust as needed
  totalPages: number = 1;
  currentMonth: string = ''; // Property to store the current month

  constructor(private dashboardService: DashboardService, public authService: AuthService, private router:Router) {}


  ngOnInit() {
    this.loadTasks();
  }



  loadTasks() {
    this.dashboardService.getUserTasks(this.authService.userProfile.userLoginDTO.userId).subscribe(tasks => {
      this.tasks = tasks;
      this.processTasks();
    });
  }

  processTasks() {
    // Sort tasks by due date
    this.tasks.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

    // Filter and organize tasks by date
    this.filteredTasks = this.tasks.reduce((acc: { [date: string]: Task[] }, task: Task) => {
      const date = new Date(task.dueDate).toDateString();
      if (!acc[date]) {
        acc[date] = [];
        this.dates.push(date);
      }
      acc[date].push(task);
      return acc;
    }, {});

    // Handle pagination
    this.totalPages = Math.ceil(this.dates.length / this.tasksPerPage);
    this.updatePaginatedDates();
    this.updateMonth(); // Update the month when tasks are processed
  }

  updatePaginatedDates() {
    const start = (this.currentPage - 1) * this.tasksPerPage;
    const end = start + this.tasksPerPage;
    this.paginatedDates = this.dates.slice(start, end);
    this.updateMonth(); // Update the month when paginated dates change
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
      this.updatePaginatedDates();
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
      this.updatePaginatedDates();
    }
  }

  getDayOfWeek(date: string): string {
    return new Date(date).toLocaleDateString('en-US', { weekday: 'short' });
  }

  getFormattedDate(date: string): string {
    return new Date(date).toLocaleDateString('en-US', { day: '2-digit' });
  }

  updateMonth() {
    if (this.paginatedDates.length > 0) {
      const firstDate = new Date(this.paginatedDates[0]);
      const lastDate = new Date(this.paginatedDates[this.paginatedDates.length - 1]);

      if (firstDate.getMonth() === lastDate.getMonth()) {
        // If all dates are within the same month
        this.currentMonth = firstDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
      } else {
        // If dates span multiple months
        const firstMonth = firstDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        const lastMonth = lastDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
        this.currentMonth = `${firstMonth} - ${lastMonth}`;
      }
    }
  }
    getFormattedTime(date: string): string {
      const taskDate = new Date(date);
      return taskDate.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true // Set to false for 24-hour format
      });
    }

}

